<?php
namespace Binali\Config;

use PDO;
use PDOException;
use Exception;

// Set timezone to GMT+1 (Africa/Lagos)
date_default_timezone_set('Africa/Lagos');

if (!class_exists('Binali\Config\Database')) {
    class Database {    
        private string $host = "127.0.0.1";
        private string $db_name = "entafhdn_mkdata";
        private string $username = "entafhdn_mkdata";
        private string $password = "entafhdn_mkdata";
        private ?PDO $conn = null;

    public function __construct() {
        try {
            error_log("Attempting to establish database connection...");
            $dsn = "mysql:host=" . $this->host . ";dbname=" . $this->db_name . ";charset=utf8mb4";
            $this->conn = new PDO($dsn, $this->username, $this->password);
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            
            // Set database timezone to GMT+1
            $this->conn->exec("SET time_zone = '+01:00'");
            
            error_log("Database connection established successfully");
        } catch(PDOException $e) {
            error_log("Connection Error: " . $e->getMessage());
            throw new Exception("Database connection failed: " . $e->getMessage());
        }
    }

    public function query($query, $params = []) {
        try {
            $stmt = $this->conn->prepare($query);
            $stmt->execute($params);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch(PDOException $e) {
            error_log("Query Error: " . $e->getMessage());
            throw new Exception("Database query failed");
        }
    }

    public function getConnection(): PDO {
        if (!$this->conn || !($this->conn instanceof PDO)) {
            error_log("Connection is not valid, attempting to reconnect...");
            $this->__construct();
        }
        if (!$this->conn) {
            throw new Exception("Unable to establish database connection");
        }
        return $this->conn;
    }

    public function isConnected() {
        try {
            if ($this->conn instanceof PDO) {
                $this->conn->query("SELECT 1");
                return true;
            }
            return false;
        } catch (PDOException $e) {
            error_log("Connection test failed: " . $e->getMessage());
            return false;
        }
    }

    public function execute($query, $params = []) {
        try {
            $stmt = $this->conn->prepare($query);
            $result = $stmt->execute($params);
            return $result ? $stmt->rowCount() : 0;
        } catch(PDOException $e) {
            error_log("Execute Error: " . $e->getMessage());
            throw new Exception("Database execute failed: " . $e->getMessage());
        }
    }

    public function lastInsertId() {
        try {
            return $this->conn->lastInsertId();
        } catch(PDOException $e) {
            error_log("LastInsertId Error: " . $e->getMessage());
            throw new Exception("Failed to get last insert ID");
        }
    }

    public function beginTransaction() {
        try {
            error_log("Beginning database transaction");
            return $this->conn->beginTransaction();
        } catch(PDOException $e) {
            error_log("BeginTransaction Error: " . $e->getMessage());
            throw new Exception("Failed to begin transaction: " . $e->getMessage());
        }
    }

    public function commit() {
        try {
            error_log("Committing database transaction");
            return $this->conn->commit();
        } catch(PDOException $e) {
            error_log("Commit Error: " . $e->getMessage());
            throw new Exception("Failed to commit transaction: " . $e->getMessage());
        }
    }

    public function rollBack() {
        try {
            error_log("Rolling back database transaction");
            return $this->conn->rollBack();
        } catch(PDOException $e) {
            error_log("Rollback Error: " . $e->getMessage());
            throw new Exception("Failed to rollback transaction: " . $e->getMessage());
        }
    }

    public function inTransaction() {
        try {
            return $this->conn->inTransaction();
        } catch(PDOException $e) {
            error_log("InTransaction Error: " . $e->getMessage());
            return false;
        }
    }
}
}